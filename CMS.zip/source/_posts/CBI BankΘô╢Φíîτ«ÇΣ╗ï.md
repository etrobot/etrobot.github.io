---
title: 海外银行卡办理：神州数字国际银行
categories: 资讯

---

CBI Bank银行简介

神州数字国际银行（https://www.cbibank.com/）是一家持牌经营的美国商业银行，接受波多黎各银行监管部门OCIF（Office of the Commissioner of Financial Institutions）的直接监管和审计，该机构隶属美国联邦储备系统（Fed Reserve System）。

CBiBank由香港上市公司神州数字新金融集团(08255.HK)和IDG资本联合投资，有效集合了双方在科技创新和全球化运营等方面的优势，总部位于美国波多黎各首府圣胡安，在香港、欧洲设立研发中心，在亚太区提供账户开立、转账汇款、投资理财等国际银行金融服务。

**账户费用**

汇款手续费：电汇入账26美元/笔

![](https://www.mg21.com/wp-content/uploads/2020/12/CBIBANK1.png)

### 开户流程

只需一部手机，5 分钟快速注册!需要证件:身份证、银行卡、手机号。

Step1: 安装 CBiBank APP；

Step2: 点击首页【境外账户申请】，并根据页面提示完成个人信息验证;

Step3: 进入【视频面签】，根据提示录制，确保信息的准确和完整；

Step4: 面签视频上传成功。审核将于 24 小时内完成，并以短信方式通知您。